package test;

import dominio.Produto;

public class ProdutoTest01 {
    public static void main(String[] args) {
        Produto teclado = cadastrar("Teclado", 150, 5);
        Produto mouse = cadastrar("Mouse", 80, 10);
        exibir(1, teclado);
        exibir(2, mouse);

        teclado.setPreco(-500);
        mouse.setQuantidade(-10);
        teclado.setNome("  ");
        teclado.setNome(null);
        teclado.setPreco(Double.NaN);
        verificar(teclado.getNome().equals("Teclado") && teclado.getPreco() == 150
                && mouse.getQuantidade() == 10, "Validações");
        verificar(teclado.calcularValorEstoque() == 750 && mouse.calcularValorEstoque() == 800,
                "Valor do estoque");

        // teclado.preco = 500;  // Erro de compilação: preco é private.
        teclado.adicionarEstoque(3);
        teclado.adicionarEstoque(0);
        verificar(teclado.getQuantidade() == 8, "Adição de estoque");
        System.out.println("Estoque do Teclado após a adição: " + teclado.getQuantidade());
    }

    private static Produto cadastrar(String nome, double preco, int quantidade) {
        Produto produto = new Produto();
        produto.setNome(nome);
        produto.setPreco(preco);
        produto.setQuantidade(quantidade);
        return produto;
    }

    private static void exibir(int numero, Produto produto) {
        System.out.printf("========== PRODUTO %02d ==========%n", numero);
        System.out.println("Nome: " + produto.getNome());
        System.out.println("Preço: R$ " + produto.getPreco());
        System.out.println("Quantidade: " + produto.getQuantidade());
        System.out.println("Valor do estoque: R$ " + produto.calcularValorEstoque());
        System.out.println();
    }

    private static void verificar(boolean condicao, String cenario) {
        if (!condicao) {
            throw new AssertionError(cenario);
        }
    }
}
