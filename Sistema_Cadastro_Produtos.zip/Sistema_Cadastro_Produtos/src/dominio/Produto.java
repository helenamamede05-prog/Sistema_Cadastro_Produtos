package dominio;

public class Produto {
    private String nome;
    private double preco;
    private int quantidade;

    public void setNome(String nome) {
        if (nome == null || nome.isBlank()) {
            System.out.println("Nome inválido.");
            return;
        }
        this.nome = nome.strip();
    }

    public void setPreco(double preco) {
        if (!Double.isFinite(preco) || preco < 0) {
            System.out.println("Preço inválido.");
            return;
        }
        this.preco = preco;
    }

    public void setQuantidade(int quantidade) {
        if (quantidade < 0) {
            System.out.println("Quantidade inválida.");
            return;
        }
        this.quantidade = quantidade;
    }

    public String getNome() {
        return nome;
    }

    public double getPreco() {
        return preco;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public double calcularValorEstoque() {
        return preco * quantidade;
    }

    public void adicionarEstoque(int quantidade) {
        if (quantidade <= 0 || quantidade > Integer.MAX_VALUE - this.quantidade) {
            System.out.println("Quantidade de reposição inválida.");
            return;
        }
        this.quantidade += quantidade;
    }
}
